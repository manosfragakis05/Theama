fn main() {
    let ffmpeg_dir = "c_src/ffmpeg_src";

    println!("cargo:rerun-if-changed=c_src/decoder.c");
    println!("cargo:rerun-if-changed=c_src/ffmpeg_src/config.h");

    // Tell the rust compiler where to find the static libraries
    println!("cargo:rustc-link-search=native={}/libavcodec", ffmpeg_dir);
    println!("cargo:rustc-link-search=native={}/libavutil", ffmpeg_dir);
    println!(
        "cargo:rustc-link-search=native={}/libswresample",
        ffmpeg_dir
    );

    // Compile the wrapper before its static dependencies in linker order.
    cc::Build::new()
        .file("c_src/decoder.c")
        .include(ffmpeg_dir)
        .opt_level(3)
        .flag_if_supported("-std=c11")
        .compile("custom_decoder");
    println!("cargo:rustc-link-lib=static=avcodec");
    println!("cargo:rustc-link-lib=static=swresample");
    println!("cargo:rustc-link-lib=static=avutil");

    // Emscripten Linker Flags
    println!("cargo:rustc-link-arg=-sEXPORT_ES6=1");
    println!("cargo:rustc-link-arg=-sMODULARIZE=1");

    println!("cargo:rustc-link-arg=-sALLOW_MEMORY_GROWTH=1");

    println!("cargo:rustc-link-arg=-sEXPORTED_FUNCTIONS=['_alloc_memory', '_free_memory', '_free_segment', '_get_mkv_info_fast_json', '_free_string', '_parse_cues_json', '_demuxer_set_target_channels','_demuxer_create', '_demuxer_destroy', '_demuxer_reset', '_demuxer_init', '_demuxer_get_last_error', '_demuxer_parse_chunk', '_demuxer_should_emit_segment', '_demuxer_audio_timing_version', '_demuxer_get_mp4_segment', '_demuxer_get_last_len', '_demuxer_decode_next_audio_frame', '_demuxer_flush_audio', '_demuxer_get_last_audio_dts', '_get_audio_ptr', '_demuxer_append_aac', '_demuxer_set_transcode_mode', '_demuxer_clear_subtitle_tracks', '_demuxer_add_subtitle_track', '_demuxer_get_subtitle_count', '_demuxer_pull_subtitles_json', '_demuxer_get_mfra_box']");

    println!("cargo:rustc-link-arg=-sEXPORTED_RUNTIME_METHODS=['ccall','cwrap','UTF8ToString','allocateUTF8','wasmMemory','HEAPU8']");

    println!("cargo:rustc-link-arg=-O3");

    println!("cargo:rustc-link-arg=-sWASM_BIGINT=1");
}
