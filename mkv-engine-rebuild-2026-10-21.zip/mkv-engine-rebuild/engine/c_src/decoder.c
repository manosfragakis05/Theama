#include <errno.h>
#include <limits.h>
#include <stdint.h>
#include <string.h>
#include <libavcodec/avcodec.h>
#include <libswresample/swresample.h>
#include <libavutil/channel_layout.h>
#include <libavutil/mem.h>
#include <libavutil/error.h>
#include <libavutil/intreadwrite.h>
#include <libavutil/mathematics.h>
#include <libavutil/samplefmt.h>
#if defined(__has_include)
# if __has_include(<emscripten.h>)
#  include <emscripten.h>
# else
/* Provide a no-op fallback so the code can be parsed outside Emscripten. */
#  define EMSCRIPTEN_KEEPALIVE
# endif
#elif defined(__EMSCRIPTEN__)
# include <emscripten.h>
#else
/* Provide a no-op fallback so the code can be parsed outside Emscripten. */
# define EMSCRIPTEN_KEEPALIVE
#endif

/* Keep the explicitly linked decoders used by the existing FFmpeg build. */
extern const AVCodec ff_ac3_decoder;
extern const AVCodec ff_eac3_decoder;
extern const AVCodec ff_truehd_decoder;
extern const AVCodec ff_flac_decoder;
extern const AVCodec ff_opus_decoder;

static AVCodecContext *dec_ctx;
static AVFrame *frame;
static AVPacket *pkt;
static SwrContext *swr;
static uint8_t *packet_buffer;
static unsigned int packet_capacity;
static float *audio_buffer;
#define MAX_SAMPLES 192000
#define MAX_CHANNELS 6
static int target_sample_rate = 48000;
static int target_channels = 2;
static int draining;
static AVChannelLayout input_layout;
static AVChannelLayout output_layout;
static int input_rate;
static int input_format = -1;
static int64_t audio_buffer_dts;
static int64_t next_output_dts = AV_NOPTS_VALUE;

EMSCRIPTEN_KEEPALIVE
void free_audio(void) {
    swr_free(&swr);
    avcodec_free_context(&dec_ctx);
    av_frame_free(&frame);
    av_packet_free(&pkt);
    av_freep(&packet_buffer);
    packet_capacity = 0;
    av_freep(&audio_buffer);
    av_channel_layout_uninit(&input_layout);
    av_channel_layout_uninit(&output_layout);
    input_format = -1;
    input_rate = 0;
    draining = 0;
    audio_buffer_dts = 0;
    next_output_dts = AV_NOPTS_VALUE;
}

/* source_channels describes the compressed stream; channels is the output. */
EMSCRIPTEN_KEEPALIVE
int init_audio(const char *codec_name, int sample_rate, int channels, int source_channels,
               const uint8_t *extradata, int extradata_size) {
    free_audio();
    if (!codec_name || channels < 1 || channels > MAX_CHANNELS || source_channels < 1 ||
        sample_rate <= 0 || extradata_size < 0) return AVERROR(EINVAL);
    const AVCodec *codec = NULL;
    if (strcmp(codec_name, "A_AC3") == 0) codec = &ff_ac3_decoder;
    else if (strcmp(codec_name, "A_EAC3") == 0) codec = &ff_eac3_decoder;
    else if (strcmp(codec_name, "A_TRUEHD") == 0) codec = &ff_truehd_decoder;
    else if (strcmp(codec_name, "A_FLAC") == 0) codec = &ff_flac_decoder;
    else if (strcmp(codec_name, "A_OPUS") == 0) codec = &ff_opus_decoder;
    else if (strcmp(codec_name, "A_DTS") == 0) codec = avcodec_find_decoder(AV_CODEC_ID_DTS);
    else if (strcmp(codec_name, "A_AAC") == 0 || strncmp(codec_name, "A_AAC/", 6) == 0)
        codec = avcodec_find_decoder(AV_CODEC_ID_AAC);
    if (!codec) return AVERROR_DECODER_NOT_FOUND;

    int ret = AVERROR(ENOMEM);
    dec_ctx = avcodec_alloc_context3(codec);
    frame = av_frame_alloc();
    pkt = av_packet_alloc();
    audio_buffer = av_malloc_array(MAX_SAMPLES * channels, sizeof(float));
    if (!dec_ctx || !frame || !pkt || !audio_buffer) goto fail;
    target_sample_rate = sample_rate;
    target_channels = channels;
    dec_ctx->sample_rate = sample_rate;
    dec_ctx->pkt_timebase = (AVRational){1, sample_rate};
    /* Rust supplies CodecDelay/DiscardPadding for each packet. Expose skip
     * metadata instead of letting FFmpeg also apply OpusHead pre-skip. */
    dec_ctx->flags2 |= AV_CODEC_FLAG2_SKIP_MANUAL;
    av_channel_layout_default(&dec_ctx->ch_layout, source_channels);
    av_channel_layout_default(&output_layout, target_channels);
    if (extradata_size > 0) {
        if (!extradata) { ret = AVERROR(EINVAL); goto fail; }
        dec_ctx->extradata = av_mallocz((size_t)extradata_size + AV_INPUT_BUFFER_PADDING_SIZE);
        if (!dec_ctx->extradata) goto fail;
        memcpy(dec_ctx->extradata, extradata, extradata_size);
        dec_ctx->extradata_size = extradata_size;
    }
    ret = avcodec_open2(dec_ctx, codec, NULL);
    if (ret < 0) goto fail;
    return 0;
fail:
    free_audio();
    return ret;
}

EMSCRIPTEN_KEEPALIVE
void reset_audio(void) {
    if (dec_ctx) avcodec_flush_buffers(dec_ctx);
    if (frame) av_frame_unref(frame);
    if (pkt) av_packet_unref(pkt);
    swr_free(&swr);
    av_channel_layout_uninit(&input_layout);
    input_format = -1;
    input_rate = 0;
    draining = 0;
    audio_buffer_dts = 0;
    next_output_dts = AV_NOPTS_VALUE;
}

static int append_frame(int written) {
    if (frame->sample_rate <= 0 || frame->nb_samples < 0 ||
        frame->ch_layout.nb_channels <= 0) return AVERROR_INVALIDDATA;
    uint32_t trim_start = 0, trim_end = 0;
    const AVFrameSideData *skip = av_frame_get_side_data(frame, AV_FRAME_DATA_SKIP_SAMPLES);
    if (skip && skip->size >= 10) {
        trim_start = AV_RL32(skip->data);
        trim_end = AV_RL32(skip->data + 4);
    }
    if (trim_start > (uint32_t)frame->nb_samples ||
        trim_end > (uint32_t)frame->nb_samples - trim_start) return AVERROR_INVALIDDATA;
    int64_t pts = frame->pts != AV_NOPTS_VALUE ? frame->pts :
        (next_output_dts != AV_NOPTS_VALUE ? next_output_dts : 0);
    pts += av_rescale_q(trim_start, (AVRational){1, frame->sample_rate}, dec_ctx->pkt_timebase);
    int samples = frame->nb_samples - trim_start - trim_end;
    if (pts < 0 && samples > 0) {
        int64_t negative = av_rescale_rnd(-pts, frame->sample_rate, target_sample_rate, AV_ROUND_UP);
        int extra = negative < samples ? (int)negative : samples;
        trim_start += extra;
        samples -= extra;
        pts += av_rescale_q(extra, (AVRational){1, frame->sample_rate}, dec_ctx->pkt_timebase);
    }
    if (!samples) return 0;
    if (trim_start) {
        int ret = av_samples_copy(frame->extended_data, frame->extended_data, 0, trim_start,
                                  samples, frame->ch_layout.nb_channels, frame->format);
        if (ret < 0) return ret;
    }
    frame->nb_samples = samples;
    int available = MAX_SAMPLES - written;
    if (available <= 0) return AVERROR(ENOSPC);

    /* No resampling/downmixing when the decoder already supplies our format. */
    if (!swr && frame->format == AV_SAMPLE_FMT_FLTP &&
        frame->sample_rate == target_sample_rate &&
        av_channel_layout_compare(&frame->ch_layout, &output_layout) == 0) {
        if (frame->nb_samples > available) return AVERROR(ENOSPC);
        for (int ch = 0; ch < target_channels; ++ch) {
            memcpy(audio_buffer + ch * MAX_SAMPLES + written,
                   frame->extended_data[ch], (size_t)frame->nb_samples * sizeof(float));
        }
        if (!written) audio_buffer_dts = pts;
        next_output_dts = pts + frame->nb_samples;
        return frame->nb_samples;
    }

    if (swr && (input_rate != frame->sample_rate || input_format != frame->format ||
                av_channel_layout_compare(&input_layout, &frame->ch_layout) != 0)) {
        /* Do not silently discard samples on an unsupported midstream change. */
        return AVERROR_INPUT_CHANGED;
    }
    if (!swr) {
        int ret = swr_alloc_set_opts2(&swr, &output_layout, AV_SAMPLE_FMT_FLTP,
                                     target_sample_rate, &frame->ch_layout,
                                     frame->format, frame->sample_rate, 0, NULL);
        if (ret < 0) return ret;
        ret = swr_init(swr);
        if (ret < 0) return ret;
        ret = av_channel_layout_copy(&input_layout, &frame->ch_layout);
        if (ret < 0) return ret;
        input_rate = frame->sample_rate;
        input_format = frame->format;
    }
    if (swr_get_out_samples(swr, frame->nb_samples) > available)
        return AVERROR(ENOSPC);
    uint8_t *out[MAX_CHANNELS];
    for (int ch = 0; ch < target_channels; ++ch)
        out[ch] = (uint8_t *)(audio_buffer + ch * MAX_SAMPLES + written);
    int64_t output_pts = pts - av_rescale_q(swr_get_delay(swr, frame->sample_rate),
        (AVRational){1, frame->sample_rate}, dec_ctx->pkt_timebase);
    int produced = swr_convert(swr, out, available,
                              (const uint8_t **)frame->extended_data, frame->nb_samples);
    if (produced > 0) {
        if (!written) audio_buffer_dts = output_pts;
        next_output_dts = output_pts + produced;
    }
    return produced;
}

static int receive_available(int *written) {
    for (;;) {
        int ret = avcodec_receive_frame(dec_ctx, frame);
        if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF) return ret;
        if (ret < 0) return ret;
        int produced = append_frame(*written);
        av_frame_unref(frame);
        if (produced < 0) return produced;
        *written += produced;
    }
}

/* Returns all PCM currently available for a packet, zero for codec delay,
 * or a negative FFmpeg error. Every input packet is padded and retained while
 * sending; receive_available drains ALL frames, not just the first one. */
EMSCRIPTEN_KEEPALIVE
int decode_audio(const uint8_t *data, int size, int64_t pts, uint32_t trim_start, uint32_t trim_end) {
    if (!dec_ctx || !data || size <= 0 || draining) return AVERROR(EINVAL);
    if ((unsigned int)size > UINT_MAX - AV_INPUT_BUFFER_PADDING_SIZE)
        return AVERROR(EINVAL);
    av_fast_malloc(&packet_buffer, &packet_capacity,
                   (size_t)size + AV_INPUT_BUFFER_PADDING_SIZE);
    if (!packet_buffer) return AVERROR(ENOMEM);
    memcpy(packet_buffer, data, size);
    memset(packet_buffer + size, 0, AV_INPUT_BUFFER_PADDING_SIZE);
    av_packet_unref(pkt);
    pkt->data = packet_buffer;
    pkt->size = size;
    pkt->pts = pkt->dts = pts;
    uint8_t *skip = av_packet_new_side_data(pkt, AV_PKT_DATA_SKIP_SAMPLES, 10);
    if (!skip) return AVERROR(ENOMEM);
    AV_WL32(skip, trim_start);
    AV_WL32(skip + 4, trim_end);
    skip[8] = skip[9] = 0;
    int written = 0;
    int ret = avcodec_send_packet(dec_ctx, pkt);
    if (ret == AVERROR(EAGAIN)) {
        ret = receive_available(&written);
        if (ret != AVERROR(EAGAIN) && ret != AVERROR_EOF) return ret;
        ret = avcodec_send_packet(dec_ctx, pkt);
    }
    if (ret < 0) return ret;
    ret = receive_available(&written);
    if (ret != AVERROR(EAGAIN) && ret != AVERROR_EOF) return ret;
    return written;
}

EMSCRIPTEN_KEEPALIVE
int flush_audio(void) {
    if (!dec_ctx) return 0;
    int written = 0;
    int ret;
    if (!draining) {
        ret = avcodec_send_packet(dec_ctx, NULL);
        if (ret == AVERROR(EAGAIN)) {
            ret = receive_available(&written);
            if (ret != AVERROR(EAGAIN) && ret != AVERROR_EOF) return ret;
            ret = avcodec_send_packet(dec_ctx, NULL);
        }
        if (ret < 0 && ret != AVERROR_EOF) return ret;
        draining = 1;
    }
    ret = receive_available(&written);
    if (ret != AVERROR(EAGAIN) && ret != AVERROR_EOF) return ret;
    if (swr && written < MAX_SAMPLES) {
        uint8_t *out[MAX_CHANNELS];
        for (int ch = 0; ch < target_channels; ++ch)
            out[ch] = (uint8_t *)(audio_buffer + ch * MAX_SAMPLES + written);
        ret = swr_convert(swr, out, MAX_SAMPLES - written, NULL, 0);
        if (ret < 0) return ret;
        if (!written) audio_buffer_dts = next_output_dts != AV_NOPTS_VALUE ? next_output_dts : 0;
        if (next_output_dts != AV_NOPTS_VALUE) next_output_dts += ret;
        written += ret;
    }
    return written;
}

EMSCRIPTEN_KEEPALIVE
float *get_audio_ptr(void) { return audio_buffer; }

int64_t get_decoded_audio_dts(void) { return audio_buffer_dts; }

/* Borrowed error text for Rust's initialization diagnostic. */
const char *audio_error_message(int code) {
    static char message[AV_ERROR_MAX_STRING_SIZE];
    if (av_strerror(code, message, sizeof(message)) < 0)
        return "Unrecognized FFmpeg error";
    return message;
}
